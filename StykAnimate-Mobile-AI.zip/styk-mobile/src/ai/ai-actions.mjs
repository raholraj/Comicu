/**
 * Turns the assistant's reply into app commands (pure).
 *
 * The assistant answers with JSON: {"reply": "...", "actions": [{"command": "<id>"}]}.
 * Only ids from the list the app offers are kept; anything else (unknown ids,
 * commands marked dangerous, malformed entries) is dropped and reported, so a
 * reply can never run something the app did not offer. At most MAX_ACTIONS run per reply.
 */

export const MAX_ACTIONS = 5;

/** Parses a reply, tolerating a Markdown code fence around the JSON. Returns {reply, actions} or throws. */
export function parseReply(text) {
  let body = String(text ?? '').trim();
  const fence = body.match(/^```(?:json)?\s*([\s\S]*?)\s*```$/i);
  if (fence) body = fence[1];
  let data;
  try { data = JSON.parse(body); }
  catch { return {reply: String(text ?? '').trim(), actions: [], rejected: []}; }
  if (!data || typeof data !== 'object' || Array.isArray(data)) return {reply: body.trim(), actions: [], rejected: []};
  const reply = typeof data.reply === 'string' ? data.reply.trim() : '';
  const raw = Array.isArray(data.actions) ? data.actions : [];
  return {reply, actions: raw, rejected: []};
}

/**
 * Keeps the actions the app offered. `allowed` is a Set of command ids. Returns
 * {run: [ids], rejected: [{command, why}]}.
 */
export function vetActions(actions, allowed) {
  const run = [], rejected = [];
  for (const action of actions ?? []) {
    const command = typeof action?.command === 'string' ? action.command : '';
    if (!command) { rejected.push({command: String(action?.command ?? ''), why: 'malformed'}); continue; }
    if (!allowed.has(command)) { rejected.push({command, why: 'not offered'}); continue; }
    if (run.includes(command)) continue;
    if (run.length >= MAX_ACTIONS) { rejected.push({command, why: 'too many actions'}); continue; }
    run.push(command);
  }
  return {run, rejected};
}

/** The instruction text: what the assistant is for and the exact command ids it may use. */
export function buildSystemPrompt(commands) {
  const list = commands.map(c => `- ${c.id}: ${c.label}`).join('\n');
  return [
    'You are the assistant inside StykAnimate, a stick-figure animation app on a phone.',
    'Help the user make and edit animations, and explain how the app works.',
    'Reply with JSON only, no other text, in this shape:',
    '{"reply": "a short answer for the user", "actions": [{"command": "<id>"}]}',
    'Use only command ids from the list below. Use an empty actions array when no command is needed.',
    'Never invent ids. Keep the reply short and in the user\'s language.',
    'Available commands:',
    list,
  ].join('\n');
}
