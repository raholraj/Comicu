/**
 * The assistant's conversation (no DOM). `ask(text)` sends the conversation to the
 * chosen provider, reads the JSON reply, and runs the commands the reply asks for.
 * The fetch, the command list and the runner are injected, so this runs in tests.
 */
import {buildRequest, readReply} from './ai-providers.mjs';
import {buildSystemPrompt, parseReply, vetActions} from './ai-actions.mjs';

const HISTORY_LIMIT = 12;

/**
 * `commands`: [{id, label, enabled, danger}] the app offers right now. `run(id)` runs
 * one command and returns {ran, reason}. `settings` has get(). `fetch` defaults to the browser's.
 */
export function createAiChat({settings, commands, run, fetch: doFetch = globalThis.fetch, context = () => ''}) {
  const history = [];

  function offered() {
    const list = commands().filter(c => c.enabled !== false && !c.danger);
    return list;
  }

  return {
    get messages() { return history.slice(); },
    clear() { history.length = 0; },
    /**
     * Sends `text`. Returns {reply, ran, rejected} where `ran` lists command ids that ran
     * and `rejected` lists {command, why} for anything dropped. Throws on network or provider errors.
     */
    async ask(text) {
      const question = String(text ?? '').trim();
      if (!question) throw new Error('Type a message first.');
      const current = settings.get();
      const list = offered();
      const system = buildSystemPrompt(list) + (context() ? `\nCurrent app state: ${context()}` : '');
      const turn = [...history, {role: 'user', content: question}].slice(-HISTORY_LIMIT);
      const request = buildRequest({provider: current.provider, apiKey: current.apiKey, model: current.model,
        baseUrl: current.baseUrl, system, messages: turn});
      const response = await doFetch(request.url, request.init);
      const data = await response.json().catch(() => ({}));
      if (!response.ok && !data?.error) throw new Error(`The AI request failed (${response.status}).`);
      const raw = readReply(current.provider, data);
      const parsed = parseReply(raw);
      const {run: ids, rejected} = vetActions(parsed.actions, new Set(list.map(c => c.id)));
      const ran = [];
      for (const id of ids) {
        const outcome = run(id);
        if (outcome?.ran) ran.push(id);
        else rejected.push({command: id, why: outcome?.reason || 'could not run'});
      }
      history.push({role: 'user', content: question}, {role: "assistant", content: raw});
      history.splice(0, Math.max(0, history.length - HISTORY_LIMIT));
      return {reply: parsed.reply || 'Done.', ran, rejected};
    },
  };
}
