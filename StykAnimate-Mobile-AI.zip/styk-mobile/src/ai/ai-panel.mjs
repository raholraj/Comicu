/**
 * The assistant's panel: a chat sheet and a settings form, built with DOM calls.
 * Assistant text is always written with textContent, never as HTML.
 */
import {PROVIDERS, PROVIDER_IDS} from './ai-providers.mjs';

function el(tag, props = {}, children = []) {
  const node = document.createElement(tag);
  for (const [key, value] of Object.entries(props)) {
    if (key === 'class') node.className = value;
    else if (key === 'text') node.textContent = value;
    else if (key.startsWith('on')) node.addEventListener(key.slice(2), value);
    else node.setAttribute(key, value);
  }
  for (const child of children) node.append(child);
  return node;
}

/**
 * Mounts a floating AI button, a chat sheet and a settings form into `host`.
 * `chat` is createAiChat(...); `settings` is createAiSettings(...); `announce(text)` shows a toast.
 */
export function mountAiPanel({host = document.body, chat, settings, announce = () => {}}) {
  const button = el('button', {class: 'ai-fab', type: 'button', 'aria-label': 'Open AI assistant', text: 'AI'});
  const log = el('div', {class: 'ai-log', role: 'log', 'aria-live': 'polite'});
  const input = el('textarea', {class: 'ai-input', rows: '2', placeholder: 'Ask or tell me what to do…', 'aria-label': 'Message'});
  const send = el('button', {class: 'ai-send', type: 'button', text: 'Send'});
  const status = el('p', {class: 'ai-status', role: 'status'});
  const settingsForm = el('div', {class: 'ai-settings', hidden: ''});
  const sheet = el('section', {class: 'ai-sheet', hidden: '', 'aria-label': 'AI assistant'});

  const providerSelect = el('select', {'aria-label': 'Provider'},
    PROVIDER_IDS.map(id => el('option', {value: id, text: PROVIDERS[id].label})));
  const modelSelect = el('select', {'aria-label': 'Model'});
  const modelOther = el('input', {type: 'text', 'aria-label': 'Model name', placeholder: 'Model name', hidden: ''});
  const OTHER = '__other__';
  const modelInput = modelSelect;  // kept for the save path below
  const urlInput = el('input', {type: 'url', 'aria-label': 'Endpoint URL', placeholder: 'Endpoint URL'});
  const keyInput = el('input', {type: 'password', 'aria-label': 'API key', placeholder: 'API key', autocomplete: 'off'});
  const keyHelp = el('p', {class: 'ai-help'});
  const settingsMessage = el('p', {class: 'ai-status', role: 'status'});

  function fillModels(provider, current) {
    const list = PROVIDERS[provider].models ?? [];
    modelSelect.replaceChildren(...list.map(name => el('option', {value: name, text: name})),
      el('option', {value: OTHER, text: 'Other…'}));
    const known = list.includes(current);
    modelSelect.value = known ? current : (current ? OTHER : (list[0] ?? OTHER));
    modelOther.value = known ? '' : current;
    modelOther.hidden = modelSelect.value !== OTHER;
  }
  modelSelect.addEventListener('change', () => { modelOther.hidden = modelSelect.value !== OTHER; });
  function chosenModel() { return modelSelect.value === OTHER ? modelOther.value.trim() : modelSelect.value; }

  function loadSettings() {
    const current = settings.get();
    providerSelect.value = current.provider;
    fillModels(current.provider, current.model);
    urlInput.value = current.baseUrl;
    keyInput.value = current.apiKey;
    const info = PROVIDERS[current.provider];
    keyHelp.textContent = `${info.free ? 'Free tier available. ' : ''}${info.keyUrl ? `Get a key: ${info.keyUrl}` : ''}`;
  }

  providerSelect.addEventListener('change', () => { settings.update({provider: providerSelect.value}); loadSettings(); settingsMessage.textContent = ''; });
  settingsForm.append(
    el('label', {}, [el('span', {text: 'Provider'}), providerSelect]),
    el('label', {}, [el('span', {text: 'Model'}), modelSelect, modelOther]),
    el('label', {}, [el('span', {text: 'Endpoint (only for custom or Ollama)'}), urlInput]),
    el('label', {}, [el('span', {text: 'API key (stored on this device only)'}), keyInput]),
    keyHelp,
    el('div', {class: 'ai-row'}, [
      el('button', {type: 'button', text: 'Done', onclick: () => { settingsForm.hidden = true; }}),
      el('button', {type: 'button', text: 'Save', onclick: () => {
        settings.update({model: chosenModel(), baseUrl: urlInput.value, apiKey: keyInput.value});
        settingsMessage.textContent = 'Saved.';
      }}),
      el('button', {type: 'button', text: 'Remove key', onclick: () => {
        settings.clearKey(providerSelect.value); keyInput.value = ''; settingsMessage.textContent = 'Key removed.';
      }}),
    ]),
    settingsMessage,
  );

  function addMessage(role, text) {
    log.append(el('div', {class: `ai-msg ai-${role}`}, [el('p', {text})]));
    log.scrollTop = log.scrollHeight;
  }

  async function ask() {
    const text = input.value.trim();
    if (!text) return;
    addMessage('user', text);
    input.value = '';
    send.disabled = true;
    status.textContent = 'Thinking…';
    try {
      const result = await chat.ask(text);
      addMessage('assistant', result.reply);
      const notes = [];
      if (result.ran.length) notes.push(`Ran: ${result.ran.join(', ')}`);
      if (result.rejected.length) notes.push(`Skipped: ${result.rejected.map(r => `${r.command} (${r.why})`).join(', ')}`);
      status.textContent = notes.join(' · ');
    } catch (error) {
      addMessage('error', error.message || 'The AI request failed.');
      status.textContent = '';
    } finally {
      send.disabled = false;
      input.focus();
    }
  }

  send.addEventListener('click', ask);
  input.addEventListener('keydown', event => { if (event.key === 'Enter' && !event.shiftKey && !event.isComposing) { event.preventDefault(); ask(); } });

  const showSettings = () => { settingsForm.hidden = false; loadSettings(); };
  const toggleSettings = el('button', {type: 'button', class: 'ai-link', text: 'Provider & key', onclick: showSettings});
  const close = el('button', {type: 'button', class: 'ai-link', text: 'Close', 'aria-label': 'Close assistant', onclick: () => setOpen(false)});
  const explain = el('button', {type: 'button', class: 'ai-link', text: 'Explain error', 'aria-label': 'Explain the latest error', onclick: () => {
    setOpen(true);
    input.value = 'What went wrong in the app most recently, and what can I do to fix it? Be brief.';
    ask();
  }});
  const clear = el('button', {type: 'button', class: 'ai-link', text: 'Clear chat', onclick: () => { chat.clear(); log.textContent = ''; }});
  sheet.append(
    el('header', {class: 'ai-head'}, [el('strong', {text: 'Assistant'}), explain, toggleSettings, clear, close]),
    settingsForm, log, status,
    el('div', {class: 'ai-compose'}, [input, send]),
  );

  function setOpen(open) {
    sheet.hidden = !open;
    if (open) { if (!settings.get().apiKey && PROVIDERS[settings.get().provider].keyRequired) settingsForm.hidden = false; loadSettings(); input.focus(); }
  }
  button.addEventListener('click', () => setOpen(sheet.hidden));
  host.append(button, sheet);
  loadSettings();
  return {open: () => setOpen(true), close: () => setOpen(false), destroy() { button.remove(); sheet.remove(); }};
}
