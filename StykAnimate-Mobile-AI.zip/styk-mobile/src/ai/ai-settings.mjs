/**
 * The assistant's settings: which provider, its model and endpoint, and the
 * user's key for it. Stored on this device only (localStorage). Keys are kept
 * as entered; the app never sends them anywhere except the chosen provider.
 * Storage errors (private mode, a full quota) fall back to in-memory values.
 */
import {PROVIDERS, PROVIDER_IDS} from './ai-providers.mjs';

const STORAGE_KEY = 'styk.ai.settings.v1';

export function createAiSettings(storage = globalThis.localStorage) {
  let memory = null;
  const read = () => {
    if (memory) return memory;
    try { memory = JSON.parse(storage?.getItem(STORAGE_KEY) ?? 'null'); } catch { memory = null; }
    return memory ?? {};
  };
  const write = value => {
    memory = value;
    try { storage?.setItem(STORAGE_KEY, JSON.stringify(value)); } catch { /* quota or private mode: keep in memory */ }
  };

  return {
    /** Current settings for the provider: {provider, model, baseUrl, apiKey}. */
    get() {
      const stored = read();
      const provider = PROVIDER_IDS.includes(stored.provider) ? stored.provider : 'gemini';
      const keys = stored.keys && typeof stored.keys === 'object' ? stored.keys : {};
      const info = PROVIDERS[provider];
      return {
        provider,
        model: typeof stored.models?.[provider] === 'string' ? stored.models[provider] : info.defaultModel,
        baseUrl: typeof stored.baseUrls?.[provider] === 'string' ? stored.baseUrls[provider] : info.baseUrl,
        apiKey: typeof keys[provider] === 'string' ? keys[provider] : '',
      };
    },
    /** Saves a partial update: any of provider, model, baseUrl, apiKey (apiKey is per provider). */
    update(patch = {}) {
      const stored = read();
      // Resolve the provider the way get() does (a fresh install is Gemini), so a key is never filed under "undefined".
      const next = {
        provider: this.get().provider, models: {...(stored.models ?? {})}, baseUrls: {...(stored.baseUrls ?? {})},
        keys: {...(stored.keys ?? {})},
      };
      if (PROVIDER_IDS.includes(patch.provider)) next.provider = patch.provider;
      const provider = next.provider;
      if (typeof patch.model === 'string') next.models[provider] = patch.model.trim();
      if (typeof patch.baseUrl === 'string') next.baseUrls[provider] = patch.baseUrl.trim();
      if (typeof patch.apiKey === 'string') next.keys[provider] = patch.apiKey.trim();
      write(next);
      return this.get();
    },
    clearKey(provider) {
      const stored = read();
      const keys = {...(stored.keys ?? {})};
      delete keys[provider];
      write({...stored, keys});
    },
  };
}
