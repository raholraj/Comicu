/**
 * AI providers for the in-app assistant (pure: no DOM, no storage).
 *
 * Each provider turns a conversation into one HTTP request and reads the text
 * back out of the response. The user supplies their own API key; it is sent
 * only to that provider's endpoint, never to StykAnimate. Free tiers exist for
 * Gemini, Groq and OpenRouter; Ollama runs on the user's own computer and needs
 * no key. Model names change often, so every provider's model is editable.
 */

export const PROVIDERS = Object.freeze({
  gemini: Object.freeze({
    models: Object.freeze(['gemini-2.5-flash', 'gemini-2.5-flash-lite', 'gemini-2.5-pro']),
    id: 'gemini', label: 'Google Gemini', free: true, keyRequired: true,
    defaultModel: 'gemini-2.5-flash', baseUrl: 'https://generativelanguage.googleapis.com/v1beta',
    keyUrl: 'https://aistudio.google.com/apikey',
  }),
  groq: Object.freeze({
    models: Object.freeze(['llama-3.3-70b-versatile', 'llama-3.1-8b-instant']),
    id: 'groq', label: 'Groq', free: true, keyRequired: true,
    defaultModel: 'llama-3.3-70b-versatile', baseUrl: 'https://api.groq.com/openai/v1',
    keyUrl: 'https://console.groq.com/keys',
  }),
  openrouter: Object.freeze({
    models: Object.freeze(['meta-llama/llama-3.3-70b-instruct:free', 'google/gemma-3-27b-it:free']),
    id: 'openrouter', label: 'OpenRouter (free models available)', free: true, keyRequired: true,
    defaultModel: 'meta-llama/llama-3.3-70b-instruct:free', baseUrl: 'https://openrouter.ai/api/v1',
    keyUrl: 'https://openrouter.ai/keys',
  }),
  openai: Object.freeze({
    models: Object.freeze(['gpt-4o-mini', 'gpt-4o']),
    id: 'openai', label: 'OpenAI', free: false, keyRequired: true,
    defaultModel: 'gpt-4o-mini', baseUrl: 'https://api.openai.com/v1',
    keyUrl: 'https://platform.openai.com/api-keys',
  }),
  anthropic: Object.freeze({
    models: Object.freeze(['claude-haiku-4-5', 'claude-sonnet-4-5']),
    id: 'anthropic', label: 'Anthropic Claude', free: false, keyRequired: true,
    defaultModel: 'claude-haiku-4-5', baseUrl: 'https://api.anthropic.com/v1',
    keyUrl: 'https://console.anthropic.com/settings/keys',
  }),
  ollama: Object.freeze({
    models: Object.freeze(['llama3.2', 'qwen2.5']),
    id: 'ollama', label: 'Ollama (on your computer)', free: true, keyRequired: false,
    defaultModel: 'llama3.2', baseUrl: 'http://localhost:11434',
    keyUrl: 'https://ollama.com/download',
  }),
  custom: Object.freeze({
    models: Object.freeze([]),
    id: 'custom', label: 'Custom (OpenAI-compatible URL)', free: false, keyRequired: true,
    defaultModel: '', baseUrl: '', keyUrl: '',
  }),
});

/** Model names offered in the settings. They change often: the "Other" option accepts any name the provider accepts. */
export const PROVIDER_IDS = Object.freeze(Object.keys(PROVIDERS));

/**
 * The request for one turn. `messages` is [{role: 'user'|'assistant', content}], `system` is the
 * instruction text. Returns {url, init} for fetch().
 */
export function buildRequest({provider, apiKey = '', model, baseUrl, system, messages}) {
  const info = PROVIDERS[provider];
  if (!info) throw new Error(`Unknown AI provider: ${provider}`);
  const name = String(model || info.defaultModel).trim();
  if (!name) throw new Error('Enter a model name for this provider.');
  if (info.keyRequired && !apiKey) throw new Error('Add an API key for this provider in AI settings.');
  const base = String(baseUrl || info.baseUrl).replace(/\/+$/, '');
  const json = body => ({method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(body)});

  if (provider === 'gemini') {
    return {
      url: `${base}/models/${encodeURIComponent(name)}:generateContent?key=${encodeURIComponent(apiKey)}`,
      init: json({
        systemInstruction: {parts: [{text: system}]},
        contents: messages.map(m => ({role: m.role === 'assistant' ? 'model' : 'user', parts: [{text: m.content}]})),
        generationConfig: {responseMimeType: 'application/json'},
      }),
    };
  }
  if (provider === 'anthropic') {
    return {
      url: `${base}/messages`,
      init: {
        method: 'POST',
        headers: {'Content-Type': 'application/json', 'x-api-key': apiKey, 'anthropic-version': '2023-06-01',
          'anthropic-dangerous-direct-browser-access': 'true'},
        body: JSON.stringify({model: name, max_tokens: 1024, system, messages}),
      },
    };
  }
  if (provider === 'ollama') {
    return {
      url: `${base}/api/chat`,
      init: json({model: name, stream: false, format: 'json', messages: [{role: 'system', content: system}, ...messages]}),
    };
  }
  // Groq, OpenRouter, OpenAI and custom endpoints speak the OpenAI chat format.
  const headers = {'Content-Type': 'application/json'};
  if (apiKey) headers.Authorization = `Bearer ${apiKey}`;
  return {
    url: `${base}/chat/completions`,
    init: {method: 'POST', headers, body: JSON.stringify({model: name, response_format: {type: 'json_object'},
      messages: [{role: 'system', content: system}, ...messages]})},
  };
}

/** The assistant's text from a provider's JSON response. Throws with the provider's message on failure. */
export function readReply(provider, data) {
  const failure = data?.error?.message || data?.error || data?.message;
  if (failure && typeof failure === 'string') throw new Error(failure);
  let text;
  if (provider === 'gemini') text = data?.candidates?.[0]?.content?.parts?.map(part => part.text ?? '').join('');
  else if (provider === 'anthropic') text = data?.content?.map(block => block.text ?? '').join('');
  else if (provider === 'ollama') text = data?.message?.content;
  else text = data?.choices?.[0]?.message?.content;
  if (typeof text !== 'string' || !text.trim()) throw new Error('The AI returned an empty reply.');
  return text;
}
